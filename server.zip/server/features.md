=> Change Mark:
    ==> Chess : Black or White
    ==> Tictactoe : X or O